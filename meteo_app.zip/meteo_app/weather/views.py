import os
import requests
from datetime import timedelta

from django.shortcuts import render
from django.utils import timezone

from .models import WeatherSearch


def index(request):
    weather_data = None
    error = None
    from_cache = False

    history = WeatherSearch.objects.all()[:10]

    if request.method == 'POST':
        city = request.POST.get('city', '').strip()

        if not city:
            error = "Veuillez entrer un nom de ville."
        else:
            # Vérifie si une recherche récente (< 15 min) existe en base
            limite_cache = timezone.now() - timedelta(minutes=15)
            recherche_recente = WeatherSearch.objects.filter(
                city__iexact=city,
                searched_at__gte=limite_cache
            ).first()

            if recherche_recente:
                weather_data = {
                    'city': recherche_recente.city,
                    'temperature': recherche_recente.temperature,
                    'humidity': recherche_recente.humidity,
                    'description': recherche_recente.description,
                }
                from_cache = True

            else:
                api_key = os.getenv('OPENWEATHER_API_KEY')
                url = 'https://api.openweathermap.org/data/2.5/weather'
                params = {
                    'q': city,
                    'appid': api_key,
                    'units': 'metric',
                    'lang': 'fr',
                }

                try:
                    response = requests.get(url, params=params, timeout=5)
                    data = response.json()

                    if response.status_code == 200:
                        weather_data = {
                            'city': data['name'],
                            'temperature': round(data['main']['temp'], 1),
                            'humidity': data['main']['humidity'],
                            'description': data['weather'][0]['description'].capitalize(),
                        }

                        # Sauvegarde en base de données
                        WeatherSearch.objects.create(
                            city=data['name'],
                            temperature=weather_data['temperature'],
                            humidity=weather_data['humidity'],
                            description=weather_data['description'],
                        )

                        # Rafraîchit l'historique après insertion
                        history = WeatherSearch.objects.all()[:10]

                    else:
                        error = "Ville introuvable. Vérifiez l'orthographe et réessayez."

                except requests.exceptions.ConnectionError:
                    error = "Erreur de connexion. Impossible de contacter l'API météo."
                except requests.exceptions.Timeout:
                    error = "La requête a expiré. Réessayez dans quelques instants."

    context = {
        'weather_data': weather_data,
        'error': error,
        'history': history,
        'from_cache': from_cache,
    }
    return render(request, 'weather/index.html', context)
