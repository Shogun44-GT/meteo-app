from django.contrib import admin
from .models import WeatherSearch

@admin.register(WeatherSearch)
class WeatherSearchAdmin(admin.ModelAdmin):
    list_display = ('city', 'temperature', 'humidity', 'description', 'searched_at')
    list_filter = ('city',)
